#ifndef FNDER2_H
#define FNDER2_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "ZXMat.h"


extern void  fnder2(stusp1* nsp, const stusp1* sp, int  n);


#endif


