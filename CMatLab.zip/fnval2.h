#ifndef FNDVAL2_H
#define FNDVAL2_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "ZXMat.h"


extern void  fnval2(Matrix *v, const stusp1* sp, const double* s, int sLength);

#endif





